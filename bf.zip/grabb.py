import requests
import re
import os
from colorama import Fore, Back, Style

linux = 'clear'
windows = 'cls'
os.system([linux,windows][os.name == 'nt'])

merah = Fore.RED
hijau = Fore.GREEN
cyan = Fore.CYAN
biru = Fore.BLUE
batas = Style.RESET_ALL

print(biru)
print('''

██████╗  ██████╗ ███╗   ███╗ █████╗ ██╗███╗   ██╗     ██████╗ ██████╗  █████╗ ██████╗ 
██╔══██╗██╔═══██╗████╗ ████║██╔══██╗██║████╗  ██║    ██╔════╝ ██╔══██╗██╔══██╗██╔══██╗
██║  ██║██║   ██║██╔████╔██║███████║██║██╔██╗ ██║    ██║  ███╗██████╔╝███████║██████╔╝
██║  ██║██║   ██║██║╚██╔╝██║██╔══██║██║██║╚██╗██║    ██║   ██║██╔══██╗██╔══██║██╔══██╗
██████╔╝╚██████╔╝██║ ╚═╝ ██║██║  ██║██║██║ ╚████║    ╚██████╔╝██║  ██║██║  ██║██████╔╝
╚═════╝  ╚═════╝ ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝     ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ 
                       Grab by Extension & Unlimited Page

Coder : Lewster
Web : https://lews.dev
''')

class Login:
    error = None
    def __init__(self, uid, passw):
        self.uid = "lewstercode"
        self.passw = "Lews1337_Rin@$"

    def authenticate(self):
        if (self.uid == logid and self.passw == logpass):
            print ("Login successful")
        else:
            exit()
log = Login("", "")
logid = input(hijau+"Masukkan Username: ")
logpass = input(hijau+"Masukkan Password: ")


log.authenticate()
print(batas)
ext = input(cyan+"Ext > ")
page = input(cyan+"Page > ")
print(batas)

for page in range(1,int(page)):

    headers = {'User-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
    req = requests.get('https://www.sitesinformation.com/extension/'+ext+'/'+str(page), headers=headers).content.decode('utf-8')
    rex = re.findall('<a href="(.*?)">', req)

    for i in rex:
        if 'https://www.sitesinformation.com/' in rex:
            pass
        elif 'extension/' in i:
            pass
        elif 'country/' in i:
            pass
        elif 'pricing/' in i:
            pass
        else:
            rp = i.replace('/site/','').replace('/','').replace('" target="_blank','')
            print(hijau)
            print("Grab > ", rp)
            result = open('result.txt', '+a').write(str(rp)+'\n')