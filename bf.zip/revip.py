from multiprocessing.dummy import Pool
import requests
import json
import socket
from ansi.colour import fg, bg

class Reverse_IP():
    def banner(self):
        print(fg.blue + '''
        
  ____            ___ ____  
 |  _ \ _____   _|_ _|  _ \ 
 | |_) / _ \ \ / /| || |_) |
 |  _ <  __/\ V / | ||  __/ 
 |_| \_\___| \_/ |___|_|    
                            
          By : Lewster
          Website : https://lews.dev''')
        print("\n")

    def revip(self,ip):
        r = requests.get(f"https://lews.dev/r.php?ip={ip}")
        if "IPv4 Invalid" in r.text:
            print(bg.red("BAD") + fg.blue(" >>> ") + fg.yellow(ip))
        else:
            result = r.text
            print(bg.green("GOOD") + fg.blue(" >>> ") + fg.green("{} {} >>> Domains".format(self.cut(str(ip) ,15), len(result))))
            for domain in result:
                open('Results.txt', '+a').write(domain)
    
    def cut(self, ip='',leng=False):
            if leng == False:
                ret = ip
            else:
                length_string = len(ip)
                if length_string > leng:
                    ret = ip[0:leng]
                else:
                  nephi = leng-length_string
                  ret = ip+' '*nephi
            return str(ret)
                    
try:
    rev = Reverse_IP()
    rev.banner()
    ip = [i.strip() for i in open(str(input("List : "))).readlines()]
    thr = Pool(int(input("Thread: ")))
    thr.map(rev.revip,ip)
except IOError:
    print(fg.red("File Not Found"))
except FileNotFoundError:
    print(fg.red("File Not Found"))
except KeyboardInterrupt:
    print(fg.red("Keyboard Interrupt Detected"))